import React, { useState } from 'react';
import {useNavigate } from 'react-router-dom';
import "../styles/login.css"; // Import CSS file
import axios from "axios";



const Login = () => {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
  });
  const navigate = useNavigate();

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Perform login logic using formData
    axios.post('http://localhost:3001/login', formData)
      .then(result => {
        console.log(result);
        if (result.data === "success") {
          navigate("/home"); // Redirect to home page on successful login
        } else {
          // Show an error message or handle unsuccessful login
          console.log("Login unsuccessful");
        }
      })
      .catch(err => {
        // Handle network errors or other issues
        console.error("Login error:", err);
        // Show an error message to the user indicating login failure
      });
  };

  return (
    <div className="login-container">
      <h2 className="login-heading">Login Page</h2>
      <form className="login-form" onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="email">Email:</label>
          <input
            type="text"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleInputChange}
            placeholder="Enter your email"
          />
        </div>
        <div className="form-group">
          <label htmlFor="password">Password:</label>
          <input
            type="password"
            id="password"
            name="password"
            value={formData.password}
            onChange={handleInputChange}
            placeholder="Enter your password"
          />
        </div>
        <button type="submit">Login</button>
       
      </form>
    </div>
  );
};

export default Login;
