import React, { useState } from 'react';
import "../styles/register.css" // Import CSS file
import {Link, useNavigate} from 'react-router-dom';
import axios from "axios";


const Register = () => {
  const [formData, setFormData] = useState({
    name: '',
    number: '',
    email: '',
    password: '',
  });
  const navigate = useNavigate();


  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Perform registration logic using formData
    axios.post('http://localhost:3001/register', formData) // Replace 'YOUR_API_ENDPOINT' with your actual API endpoint
      .then(result => {
        console.log(result);
        // Handle success (e.g., redirect to a new page)
       navigate("/login")
      })
      .catch(err => {
        console.log(err);
        // Handle error (e.g., show error message)
      });
    console.log('Form submitted:', formData);
  };

  return (
    <div className="register-container">
      <h2 className="register-heading">Register Page</h2>
      <form className="register-form" onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="name">Name:</label>
          <input
            type="text"
            id="name"
            name="name"
            value={formData.name}
            onChange={handleInputChange}
            placeholder="Enter your name"
          />
        </div>
        <div className="form-group">
          <label htmlFor="number">Number:</label>
          <input
            type="text"
            id="number"
            name="number"
            value={formData.number}
            onChange={handleInputChange}
            placeholder="Enter your number"
          />
        </div>
        <div className="form-group">
          <label htmlFor="email">Email:</label>
          <input
            type="text"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleInputChange}
            placeholder="Enter your email"
          />
        </div>
        <div className="form-group">
          <label htmlFor="password">Password:</label>
          <input
            type="password"
            id="password"
            name="password"
            value={formData.password}
            onChange={handleInputChange}
            placeholder="Enter your password"
          />
        </div>
        <button type="submit">Register</button>
      </form>
      <p>Already Have a Account Please Login</p>
      <button><Link to={"/login"}>LogIn</Link></button> 
    </div>
  );
};

export default Register;

