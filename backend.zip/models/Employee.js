
const mongoose = require('mongoose');

// Define the User schema
const employeeSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, "Please Enter your Name"],
    maxLength: [30, "Name cannot exceed 30 characters"],
    minLength: [4, "Name should have at least 4 characters"]
},
number: {
  type: String,
  required: true
},
email: {
    type: String,
    required: [true, "Please Enter Your Email"],
    unique: true,
},
password: {
    type: String,
    required: [true, "Please Enter Your Password"],
    minLength: [8, "Password should be at least 8 characters long"],
}
});

// Create a User model using the schema
const employeeModel = mongoose.model('employees', employeeSchema);

module.exports = employeeModel;
